/*
The case of the Python Syndicate
Stage 2


Officer: 7129607
CaseNum: 301-1-99093948-7129607

- Word on the street is that there is a new gang in town - The Python Syndicate.
It seems my bones were correct on this one. I need you to organise the gang
around the suspected leader Cecil karpinski

- The variables for Cecil karpinski have been declared and
initialised.
- Modify the x and y parameters of each image command using these two variables
so the images maintain their correct positions their correct positions on the board.
- To do this you will need to combine add and subtract operators with variables
Cecil karpinski for for each parameter.
- Do not create any new variables
- Do not add any additional commands


*/

var photoBoard;
var robbieKrayImg;
var pawelKarpinskiImg;
var bonesKarpinskiImg;
var cecilKarpinskiImg;
var rockyKrayImg;
var annaKarpinskiImg;


var cecilKarpinskiPosX = 115;
var cecilKarpinskiPosY = 309;


function preload()
{
	photoBoard = loadImage('photoBoard.png');
	robbieKrayImg = loadImage("krayBrothers2.png");
	pawelKarpinskiImg = loadImage("karpinskiBros2.png");
	bonesKarpinskiImg = loadImage("karpinskiDog.png");
	cecilKarpinskiImg = loadImage("karpinskiBros1.png");
	rockyKrayImg = loadImage("krayBrothers1.png");
	annaKarpinskiImg = loadImage("karpinskiWoman.png");

}

function setup()
{
	createCanvas(photoBoard.width, photoBoard.height);
}

function draw()
{
	image(photoBoard, 0, 0);

	//And update these image commands with your x and y coordinates.
	image(cecilKarpinskiImg, cecilKarpinskiPosX, cecilKarpinskiPosY);

	//image(robbieKrayImg, 115, 40);
	//image(pawelKarpinskiImg, 408, 40);
	//image(bonesKarpinskiImg, 701, 40);
	//image(rockyKrayImg, 408, 309);
	//image(annaKarpinskiImg, 701, 309);

}